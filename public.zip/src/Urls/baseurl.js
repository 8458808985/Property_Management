// const BASE_URL = "https://property-managment-1.onrender.com/api/v1";
// export default BASE_URL;

const BASE_URL = "https://test1.buyjugaad.com/pp/api/v1";
export default BASE_URL;
